
source common.sh
component=catalogue


nodejs

mongo_schema_setup
