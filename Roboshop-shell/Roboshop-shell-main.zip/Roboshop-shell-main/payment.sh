
source common.sh
component=payment


roboshop_app_password=$1
echo $roboshop_app_password
python