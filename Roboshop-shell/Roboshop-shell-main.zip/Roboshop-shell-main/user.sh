source common.sh
component=user


nodejs

mongo_schema_setup