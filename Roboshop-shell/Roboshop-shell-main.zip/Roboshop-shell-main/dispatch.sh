
source common.sh
component=dispatch

golang