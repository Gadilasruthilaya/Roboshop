source common.sh
component=shipping

maven


